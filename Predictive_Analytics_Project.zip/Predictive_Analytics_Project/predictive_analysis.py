import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error

# Load dataset
df = pd.read_csv("Advertising.csv")

print(df.head())

# Select feature and target
X = df[['TV']]
y = df['Sales']

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

# Train model
model = LinearRegression()
model.fit(X_train, y_train)

# Predictions
y_pred = model.predict(X_test)

# Accuracy
error = mean_absolute_error(y_test, y_pred)

print("Mean Absolute Error:", error)

# Visualization
plt.scatter(X_test, y_test, color='blue')
plt.plot(X_test, y_pred, color='red')

plt.title("Sales Prediction using Linear Regression")
plt.xlabel("TV Advertising Budget")
plt.ylabel("Sales")

plt.show()