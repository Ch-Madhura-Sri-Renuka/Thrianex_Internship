import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("sales_data.csv", encoding='latin1')

# Show first 5 rows
print(df.head())

# Remove duplicate rows
df = df.drop_duplicates()

# Fill missing values with 0
df = df.fillna(0)

# Make column names lowercase
df.columns = df.columns.str.lower()

# Save cleaned data
df.to_csv("cleaned_data.csv", index=False)

# Create summary report
summary = df.describe()

# Save report in Excel
summary.to_excel("summary_report.xlsx")

# Create chart
numeric_columns = df.select_dtypes(include=['number']).columns

if len(numeric_columns) > 0:
    df[numeric_columns[0]].plot(kind='hist')
    plt.title("Data Distribution")
    plt.savefig("chart.png")

print("Project Completed Successfully")